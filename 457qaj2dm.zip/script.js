const STORAGE_KEY = 'appboard-apps-v1';
const starterApps = [];

const statusLabels = {
  active: 'Đang hoạt động',
  maintenance: 'Bảo trì',
  inactive: 'Tạm dừng'
};

const tableBody = document.getElementById('appsTableBody');
const searchInput = document.getElementById('searchInput');
const appDialog = document.getElementById('appDialog');
const appForm = document.getElementById('appForm');
let apps = loadApps();

function loadApps() {
  try {
    const savedApps = localStorage.getItem(STORAGE_KEY);
    return savedApps === null ? starterApps : JSON.parse(savedApps);
  } catch (error) {
    return starterApps;
  }
}

function saveApps() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
}

function formatDate(timestamp) {
  return new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(timestamp));
}

function renderApps() {
  const query = searchInput.value.trim().toLocaleLowerCase('vi');
  const visibleApps = apps.filter((app) =>
    `${app.name} ${app.platform}`.toLocaleLowerCase('vi').includes(query)
  );

  document.getElementById('fileCount').textContent = apps.filter((app) => app.fileData).length;
  document.getElementById('emptyState').hidden = visibleApps.length > 0;
  document.getElementById('listSummary').textContent = `Hiển thị ${visibleApps.length} / ${apps.length} ứng dụng`;

  tableBody.innerHTML = visibleApps.map((app, index) => `
    <tr>
      <td><div class="app-name-cell"><span class="app-avatar color-${index % 4}">${escapeHtml(app.name.charAt(0))}</span>${escapeHtml(app.name)}</div></td>
      <td>${escapeHtml(app.platform)}</td>
      <td><span class="badge ${app.status}">${statusLabels[app.status] || statusLabels.inactive}</span></td>
      <td>${formatDate(app.updatedAt)}</td>
      <td><div class="row-actions">
        <button class="icon-button" type="button" data-action="download" data-id="${escapeHtml(app.id)}" aria-label="Tải tệp của ${escapeHtml(app.name)}" title="${app.fileData ? 'Tải tệp' : 'Chưa có tệp để tải'}" ${app.fileData ? '' : 'disabled'}>↓</button>
        <button class="icon-button" type="button" data-action="edit" data-id="${escapeHtml(app.id)}" aria-label="Sửa ${escapeHtml(app.name)}" title="Sửa">✎</button>
        <button class="icon-button delete" type="button" data-action="delete" data-id="${escapeHtml(app.id)}" aria-label="Xóa ${escapeHtml(app.name)}" title="Xóa">⌫</button>
      </div></td>
    </tr>`).join('');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function openNewAppDialog() {
  appForm.reset();
  document.getElementById('appId').value = '';
  document.getElementById('dialogTitle').textContent = 'Thêm ứng dụng';
  document.getElementById('currentFileName').textContent = '';
  appDialog.showModal();
  document.getElementById('appName').focus();
}

function editApp(id) {
  const app = apps.find((item) => item.id === id);
  if (!app) return;
  document.getElementById('appId').value = app.id;
  document.getElementById('appName').value = app.name;
  document.getElementById('appPlatform').value = app.platform;
  document.getElementById('appStatus').value = app.status;
  document.getElementById('currentFileName').textContent = app.fileName ? `Tệp hiện tại: ${app.fileName}` : '';
  document.getElementById('dialogTitle').textContent = 'Chỉnh sửa ứng dụng';
  appDialog.showModal();
  document.getElementById('appName').focus();
}

document.getElementById('addAppButton').addEventListener('click', openNewAppDialog);
document.getElementById('closeDialogButton').addEventListener('click', () => appDialog.close());
document.getElementById('cancelButton').addEventListener('click', () => appDialog.close());
searchInput.addEventListener('input', renderApps);

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

appForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const id = document.getElementById('appId').value;
  const existingApp = apps.find((app) => app.id === id);
  const selectedFile = document.getElementById('Wed').files[0];
  let fileData = existingApp?.fileData || '';
  if (selectedFile) {
    try {
      fileData = await readFileAsDataUrl(selectedFile);
    } catch (error) {
      window.alert('Không thể đọc tệp đã chọn. Vui lòng thử lại.');
      return;
    }
  }
  const appData = {
    id: id || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    name: document.getElementById('appName').value.trim(),
    platform: document.getElementById('appPlatform').value,
    status: document.getElementById('appStatus').value,
    fileName: selectedFile?.name || existingApp?.fileName || '',
    fileData,
    updatedAt: Date.now()
  };

  if (!appData.name) return;
  const previousApps = apps;
  if (existingApp) {
    apps = apps.map((app) => app.id === id ? appData : app);
  } else {
    apps.unshift(appData);
  }
  try {
    saveApps();
  } catch (error) {
    apps = previousApps;
    window.alert('Không thể lưu. Tệp có thể quá lớn so với dung lượng lưu trữ của trình duyệt.');
    return;
  }
  renderApps();
  appDialog.close();
});

tableBody.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const id = button.dataset.id;

  if (button.dataset.action === 'download') {
    const app = apps.find((item) => item.id === id);
    if (!app?.fileData) return;
    const link = document.createElement('a');
    link.href = app.fileData;
    link.download = app.fileName || 'tep-dinh-kem';
    document.body.appendChild(link);
    link.click();
    link.remove();
  } else if (button.dataset.action === 'edit') {
    editApp(id);
  } else if (button.dataset.action === 'delete') {
    const app = apps.find((item) => item.id === id);
    if (app && window.confirm(`Bạn có chắc muốn xóa “${app.name}” không?`)) {
      const previousApps = apps;
      apps = apps.filter((item) => item.id !== id);
      try {
        saveApps();
        renderApps();
      } catch (error) {
        apps = previousApps;
        window.alert('Không thể lưu thay đổi. Vui lòng thử lại.');
      }
    }
  }
});

renderApps();
